var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-order.ts
var create_order_exports = {};
__export(create_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_order_exports);
var b64 = (s) => Buffer.from(s).toString("base64");
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders(event), body: "ok" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const { amount, currency = "INR", receipt = `rcpt_${Date.now()}`, notes = {} } = JSON.parse(event.body || "{}");
    console.log("KEY_ID:", process.env.RAZORPAY_KEY_ID);
    console.log("KEY_SECRET:", process.env.RAZORPAY_KEY_SECRET ? "*****" : "MISSING");
    if (!amount || !Number.isInteger(amount) || amount <= 0) {
      return resp(400, { error: "amount (paise) required" }, event);
    }
    const res = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        Authorization: "Basic " + b64(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ amount, currency, receipt, notes })
    });
    const data = await res.json();
    return resp(res.status, data, event);
  } catch (e) {
    return resp(500, { error: e?.message || "create failed" }, event);
  }
};
function corsHeaders(event) {
  const origin = event?.headers?.origin || "";
  const allowed = (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim());
  const allow = allowed.includes(origin) ? origin : "";
  return {
    "Access-Control-Allow-Origin": allow || "*",
    // tighten in prod
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
    "Content-Type": "application/json"
  };
}
function resp(status, body, event) {
  return { statusCode: status, headers: corsHeaders(event), body: JSON.stringify(body) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=create-order.js.map
